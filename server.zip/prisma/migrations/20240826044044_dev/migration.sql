/*
  Warnings:

  - You are about to drop the column `compleated` on the `commend` table. All the data in the column will be lost.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_commend" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "request" TEXT NOT NULL,
    "completed" BOOLEAN NOT NULL DEFAULT false,
    "clientId" TEXT,
    CONSTRAINT "commend_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES "client" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_commend" ("clientId", "id", "request") SELECT "clientId", "id", "request" FROM "commend";
DROP TABLE "commend";
ALTER TABLE "new_commend" RENAME TO "commend";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
