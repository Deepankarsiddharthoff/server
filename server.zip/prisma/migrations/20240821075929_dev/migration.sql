/*
  Warnings:

  - Added the required column `topic` to the `client` table without a default value. This is not possible if the table is not empty.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_client" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "model" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "provider" TEXT NOT NULL,
    "topic" TEXT NOT NULL
);
INSERT INTO "new_client" ("id", "model", "name", "provider") SELECT "id", "model", "name", "provider" FROM "client";
DROP TABLE "client";
ALTER TABLE "new_client" RENAME TO "client";
CREATE TABLE "new_commend" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "request" TEXT NOT NULL,
    "compleated" BOOLEAN NOT NULL DEFAULT false,
    "clientId" TEXT,
    CONSTRAINT "commend_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES "client" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_commend" ("clientId", "id", "request") SELECT "clientId", "id", "request" FROM "commend";
DROP TABLE "commend";
ALTER TABLE "new_commend" RENAME TO "commend";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
