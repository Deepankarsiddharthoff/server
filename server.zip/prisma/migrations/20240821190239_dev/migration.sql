/*
  Warnings:

  - You are about to drop the column `model` on the `client` table. All the data in the column will be lost.
  - You are about to drop the column `name` on the `client` table. All the data in the column will be lost.
  - You are about to drop the column `provider` on the `client` table. All the data in the column will be lost.
  - You are about to alter the column `topic` on the `client` table. The data in that column could be lost. The data in that column will be cast from `String` to `Int`.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_client" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "topic" INTEGER
);
INSERT INTO "new_client" ("id", "topic") SELECT "id", "topic" FROM "client";
DROP TABLE "client";
ALTER TABLE "new_client" RENAME TO "client";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
