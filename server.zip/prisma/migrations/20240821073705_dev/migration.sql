-- CreateTable
CREATE TABLE "client" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "model" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "providers" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "commend" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "request" TEXT NOT NULL,
    "clientId" TEXT,
    CONSTRAINT "commend_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES "client" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "data" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "value" TEXT NOT NULL,
    "commendId" TEXT,
    CONSTRAINT "data_commendId_fkey" FOREIGN KEY ("commendId") REFERENCES "commend" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
