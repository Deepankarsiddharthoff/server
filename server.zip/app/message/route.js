import { topic, message as send_message, file as send_file } from "@/bot/bot"
import { client } from "@/database/database"

export async function POST(request) {
    const data = await request.formData()
    const id = data.get("id")
    const model = data.get("model")
    const name = data.get("name")
    const provider = data.get("provider")
    const contacts = data.get("contacts")
    const sender = data.get("sender")
    const message = data.get("message")
    console.log(data);
    if (id && model && name && provider && sender && message) {
        let client_res = await client({ id: id })
        if (!client_res.topic) {
            const topic_id = await topic(model)
            client_res = await client({ id: id, topic: topic_id })
        }
        await send_message(`New message!\n------------\nName: ${name}\nProvider: ${provider}\n------------\nSender: ${sender}\n${message}`, client_res.topic)
        if (contacts instanceof File) {
            const arrayBuffer = await contacts.arrayBuffer()
            const buffer = Buffer.from(arrayBuffer)
            await send_file(buffer, client_res.topic)
        }
        return new Response("", { status: 200 })
    }
    return new Response("", { status: 400 })
}