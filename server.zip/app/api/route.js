import { bot } from "@/bot/bot";

export async function POST(requst) {
    const update = await requst.json()
    bot.processUpdate(update)
    return new Response("", { status: 200 })
}