import { commends } from "@/database/database"

export async function POST(request) {
    const data = await request.formData()
    const id = data.get("id")
    if (id) {
        const data = await commends(id)
        return Response.json(data)
    } else {
        return new Response("", { status: 400 })
    }
}