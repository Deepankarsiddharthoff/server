/*
  Warnings:

  - You are about to drop the column `providers` on the `client` table. All the data in the column will be lost.
  - Added the required column `provider` to the `client` table without a default value. This is not possible if the table is not empty.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_client" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "model" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "provider" TEXT NOT NULL
);
INSERT INTO "new_client" ("id", "model", "name") SELECT "id", "model", "name" FROM "client";
DROP TABLE "client";
ALTER TABLE "new_client" RENAME TO "client";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
