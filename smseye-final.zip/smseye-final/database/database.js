import { PrismaClient } from "@prisma/client"
import { readFileSync, writeFileSync } from "fs"

const db = new PrismaClient()

export async function client(client) {
    try {
        const res = await db.client.upsert({
            where: { id: client.id },
            create: client,
            update: client
        })
        return res
    } catch (e) {
        console.log(e)
        return undefined
    }
}

export async function commend(topic, { request, data }) {
    try {
        const { id } = await db.client.findFirst({ where: { topic: topic } })
        const res = await db.client.update({
            where: { id: id },
            data: { commends: { create: { request: request, data: { create: data } } } }
        })
        return res
    } catch (e) {
        console.log(e)
        return undefined
    }
}

export async function commends(clientId) {
    try {
        const res = await db.commend.findMany({
            where: { clientId: clientId, completed: false },
            include: { data: true }
        })
        await db.commend.updateMany({
            where: { completed: false },
            data: { completed: true }
        })
        return res
    } catch (e) {
        console.log(e)
        return undefined
    }
}

export async function read_group() {
    try {
        const data = await readFileSync('./database/group.txt', 'utf-8')
        return data
    } catch (e) {
        console.error(e)
    }
}

export async function write_group(id) {
    try {
        await writeFileSync('./database/group.txt', id);
    } catch (e) {
        console.error(e);
    }
}