export default function Home() {
    return (
        <main className="">
            <p>SERVER IS UP AND RUNNING</p>
        </main>
    );
}
