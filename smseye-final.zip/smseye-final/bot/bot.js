import TelegramBot from "node-telegram-bot-api"
import { read_group, write_group, read_tokne } from "@/database/database"
import { commend } from "@/database/database"

const url = process.env.URL
const token = process.env.TOKEN

export const bot = new TelegramBot(token, { request: { proxy: "http://127.0.0.1:9080" } })

bot.setWebHook(`${url}/api`)

export async function message(message, topic) {
    const chat = await read_group()
    try {
        await bot.sendMessage(chat, message, { message_thread_id: topic })
        return "ok"
    } catch (e) {
        console.log(e)
        return undefined
    }
}

export async function file(file, topic) {
    const chat = await read_group()
    try {
        await bot.sendDocument(chat, file, { message_thread_id: topic }, { contentType: "*/*", filename: "contatcs.txt" })
        return "ok"
    } catch (e) {
        console.log(e)
        return undefined
    }
}

export async function topic(model) {
    const chat = await read_group()
    try {
        const { message_thread_id } = await bot.createForumTopic(chat, model)
        return message_thread_id
    } catch (e) {
        console.log(e)
        return undefined
    }
}

bot.on("message", async msg => {
    if (msg.text == "/set") {
        await write_group(msg.chat.id + "")
        await message("This group has been set!", 0)
    }
    if (msg.text && msg.text.substring(0, 5) == "/send") {
        const number = msg.text.split(" ")[1]
        const text = msg.text.split(" ")[2]
        await commend(msg.message_thread_id,
            {
                request: "send",
                data: [
                    { name: "number", value: number },
                    { name: "text", value: text }
                ]
            })
        await message("Request submited!", msg.message_thread_id)
    }
})



